import Foundation
//Tutorial follow along to prep for quiz 2 on February26th
//FUNCTIONS use camel case
func noArgumentsAndNoReturnVal(){
    "I don't know what I am doing"
}
noArgumentsAndNoReturnVal()

func plusTwo(value:Int){
    let newValue = value+2
}

plusTwo(value:30)

func newPlusTwo(value:Int) -> Int {
    return value + 2 //don't need to say return, new code already knows
}

newPlusTwo(value:30)



func customAdd(value1:Int, value2:Int) -> Int{
    value1+value2
}
let customAdded = customAdd(value1:10, value2:20)


func customMinus(lhs: Int, rhs: Int) -> Int{
    lhs-rhs
}
let customSubtracted = customMinus(lhs:20, rhs:10)

//so u don't have to specify lhs and rhs

func newCustomMinus( _ lhs: Int, _ rhs: Int) -> Int{
    lhs-rhs
}
let newCustomSubtracted = newCustomMinus(20,10)


