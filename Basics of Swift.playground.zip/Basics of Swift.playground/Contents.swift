// Notes for understanding very basic swift on Feb 13th
//DT Types:
//String “hi how are you”
//Int 12
// when doing simple things, make sure that when multiplying numbers, make everything
// Double - like an int but decimal with higher precision 2.3456 (like a float but more used in Swift)
// Bool (Boolean) true false

import Foundation //this imports all functions
// create variable a of type string
var myVar:String = “Angie”
//myVar = 10 <- error
myVar = “bye”
print(myVar)
//Camel Space= naming a var startWithLower <- where every new word starts with capital letter

var myInt:Int = 20
myInt += 1
print(myInt)

var cVar = “hi” //don’t need to declare type bc swift is smart!
print(cVar)

//CONSTANTS

let myConst:String = “hello”
// myConst = “world” <- will give you an error
print(myConst) // <- when variable is NOT going to change, use it. Or things third parties // shouldn't access

var a:Double = 2
var b:Double = 5
var c = abs(a)
print(c) //or print(abs(a))
var myPow = pow(a,b)
print(c)

//ERROR
//var a = 2
//var b= 5
//var c = abs(a)
//print(c) //or print(abs(a))
//var myPow = pow(a,b)
//print(c)

var d:Double = 2
var e:Double = 5
var m = sqrt(a)
print(m) //or print(abs(a))


//ceiling vs. floor
var j:Double = 2.3
var k:Double = 5.8
var t = floor(j)
var g = ceil(k)
print(t)
print(d)


// Excersice Concept Check 1

var friend1:Double = 0.0
var friend2:Double = 0.0
var friend3:Double = 0.0

var beforeTax:Double = 15.0
var totalTax:Double = beforeTax * 0.0833
var grandTotal:Double = beforeTax + totalTax
var perStudent:Double = grandTotal/3

friend1 += perStudent
friend2 += perStudent
friend2 += perStudent

Print("Each friend owes ", perStudent)

//functions
func myFunc(){
    let k = 10
    let l = 5
    print(a+b)
} //nothing happens until you call the funtion

// function calling
myFunc() //now it will print

//functions with parameter
func myFunc(k:Int){
    //let k = 10
    let l = 5
    print(a+b)
} //nothing happens until you call the funtion

// function calling //now it will print MUST give it the parameters
myFunc(a:10) //must input the same # of parameters when calling as when declared


func aFunc(a:Int,)->Int{
    //let a =10
    let b = 5
    var z = a+b
    return(z) //return("hi") would give an error
  //print("done") if placed after return statement it WON'T print it
}

//Function Calling
print(aFunc(a:10))

func aFunc(a:Int,b:Int)->Int{
    return(a+b) //return("hi") would give an error
  //print("done") if placed after return statement it WON'T print it
}

//function calling
print(aFunc(a:10, b:5))

func aFunc(a:Int,b:Int=0)->Int{
    return(a+b) //return("hi") would give an error
  //print("done") if placed after return statement it WON'T print it
}
// both the below work
print(aFunc(a: 20))
print(aFunc(a:10, b:5))

//argument
func myFunc (first a:Int, second b:Int=0)->Int{
    return(a+b)
}
//calling
print(myFunc(first: 20))
print(myFunc(first: 10, second: 5)

//underscore PREFERRED BY DR RAJIV STANDARD
func myFunc (_ a:Int, _ b:Int=0)->Int{
    return(a+b)
}
//calling both the below work
print(myFunc(20)) //used so you can do this without adding anything extra other than the num
print(myFunc(10, 5))

//FUNCTION OVERLOADING
// for when multiple functions have the same name, but with diff signatures
//depending on how you call the function, Xcode will know which u want


//CHECKPOINT #2
func conceptCheck(_ beforeTax:Double , _ taxDecimas:Double = 0.0833)->Double{
    var grandTotal:Double = (beforeTax*taxDecimas) + totalTax
    return(grandTotal/3)
}

print(conceptCheck(15))


//structures are super important <- similar to a class
// do NOT use CAMEL CASE in struct, start with Capital
struct MyStruct{
    //variables and conditions: variables and conditions inside structures are PROPERTIES
    //functions: METHODS
}

struct ChatView{
    var msg = "Rose is still alive" // is a STORED PROPERTY because it is being initialized
    var msgWithPrefix:String{ //COMPUTED PROPERTY
        return "Jack says " +msg
    }
    // UI code: View Code

    //functions: METHODS
    func sendChat(){
        //code to send chat
        print(msg)
        print(msgWithPrefix)
    }

    func deleteChat(){
        //code to delete chat
        print(msg)
        print(msgWithPrefix)
    }
}

















