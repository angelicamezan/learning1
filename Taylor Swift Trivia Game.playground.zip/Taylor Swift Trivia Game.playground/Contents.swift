import Foundation
//Taylor swift because I am bored on 3/14
// Define Taylor Swift albums and their  tour names
let taylorSwiftAlbums = ["Taylor Swift", "Fearless", "Speak Now", "Red", "1989", "Reputation", "Lover"]
let tourNames = ["Fearless Tour", "Speak Now World Tour", "Red Tour", "The 1989 World Tour", "Reputation Stadium Tour", "Lover Fest"]

// Define trivia questions and answers for each album
let triviaQuestions = [
    "Taylor Swift": "In which year was Taylor Swift's debut album released?",
    "Fearless": "Which song from 'Fearless' won the Album of the Year at the Grammys?",
    "Speak Now": "Taylor Swift wrote 'Speak Now' entirely by herself. True or False?",
    "Red": "Which song from 'Red' was rumored to be about Taylor's relationship with Jake Gyllenhaal?",
    "1989": "What is the name of the first single from the '1989' album?",
    "Reputation": "What is the name of Taylor Swift's first single from her 'Reputation' album?",
    "Lover": "Taylor Swift collaborated with Brendon Urie of Panic! at the Disco on a song from the 'Lover' album. What is the song called?"
]

let triviaAnswers = [
    "Taylor Swift": "2006",
    "Fearless": "Fearless",
    "Speak Now": "True",
    "Red": "All Too Well",
    "1989": "Shake It Off",
    "Reputation": "Look What You Made Me Do",
    "Lover": "ME!"
]

// Function to present trivia questions and validate answers
func presentTrivia(for album: String) -> Bool {
    guard let question = triviaQuestions[album], let answer = triviaAnswers[album] else {
        print("Trivia not found for \(album).")
        return false
    }
    
    print(question)
    if let userAnswer = readLine(), userAnswer.lowercased() == answer.lowercased() {
        print("Correct!")
        return true
    } else {
        print("Incorrect. The correct answer is: \(answer)")
        return false
    }
}

// Main game loop
func playTaylorSwiftGame() {
    print("Welcome to the Taylor Swift Eras Tour Game!")
    print("Collect tickets for each era's tour by answering trivia questions.")
    print("Let's begin!\n")
    
    var collectedTickets = Set<String>()
    
    while collectedTickets.count < tourNames.count {
        for (index, album) in taylorSwiftAlbums.enumerated() {
            if !collectedTickets.contains(tourNames[index]) {
                print("You're collecting tickets for \(tourNames[index])")
                if presentTrivia(for: album) {
                    print("You've collected a ticket for \(tourNames[index])!\n")
                    collectedTickets.insert(tourNames[index])
                } else {
                    print("Try again!\n")
                }
            }
        }
    }
    
    print("Congratulations! You've collected tickets for all Taylor Swift eras' tours!")
}

// Start the game
playTaylorSwiftGame()
