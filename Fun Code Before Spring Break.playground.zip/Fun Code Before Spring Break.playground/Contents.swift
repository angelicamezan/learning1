import Foundation
// Created March 13th, 2024

class VirtualPet {
    var name: String
    var happiness: Int
    var energy: Int
    
    init(name: String) {
        self.name = name
        happiness = 50
        energy = 50
    }
    
    func play() {
        print("\(name) is playing!")
        happiness += 10
        energy -= 10
        checkStatus()
    }
    
    func feed() {
        print("\(name) is eating!")
        happiness += 5
        energy += 10
        checkStatus()
    }
    
    func sleep() {
        print("\(name) is sleeping!")
        happiness += 5
        energy += 20
        checkStatus()
    }
    
    func checkStatus() {
        if happiness > 100 {
            happiness = 100
        }
        if energy > 100 {
            energy = 100
        }
        if happiness < 0 {
            happiness = 0
        }
        if energy < 0 {
            energy = 0
        }
        
        if happiness <= 0 || energy <= 0 {
            print("\(name) has run away! Game over.")
            exit(0)
        }
        
        print("\(name)'s happiness: \(happiness), energy: \(energy)")
    }
}

print("Welcome to Swiftie - Your Virtual Taylor Nation Pet!")
print("What would you like to name your pet?")
if let name = readLine() {
    let swiftie = VirtualPet(name: name)
    print("You now have a pet named \(swiftie.name)!")

    while true {
        print("What would you like to do with \(swiftie.name)? (play/feed/sleep/quit)")
        if let action = readLine() {
            switch action {
            case "play":
                swiftie.play()
            case "feed":
                swiftie.feed()
            case "sleep":
                swiftie.sleep()
            case "quit":
                print("Goodbye!")
                exit(0)
            default:
                print("Invalid action. Please try again.")
            }
        }
    }
} else {
    print("Invalid input. Please try again.")
}
