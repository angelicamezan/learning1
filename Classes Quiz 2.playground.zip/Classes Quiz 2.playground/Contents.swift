import Foundation
// short class tutorial review for Quiz 2 Feb 29th
//CLASSES are like structures but they are reference types and they allow for mutability
//must create constructors in classes where structures don't need it
//classes allow for internal mutability
class Person{
    var name: String
    var age: Int
    
    init(
        name:String,
        age:Int){
            self.name = name
            self.age = age
        }
    func increaseAge(){
        self.age +=1
    }
}

let foo = Person(name:foo, age:20)
foo.age
foo.increaseAge()
foo.age
