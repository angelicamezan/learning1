import Foundation
//This is a random fun game kinda I made to review for our midterm coming up this next week
//Created March 16th
// Define a class representing a student
class Student {
    var name: String
    
    init(name: String) {
        self.name = name
    }
    
    // Method to explore Swift playgrounds
    func exploreSwiftPlaygrounds() {
        print("\(name) is exploring Swift playgrounds!")
        print("This is a great way to learn and understand how Swift code works.\n")
    }
}

// Define a class representing a dog
class Dog {
    var name: String
    
    init(name: String) {
        self.name = name
    }
    
    // Method to bark
    func bark() {
        print("\(name): Woof woof!")
    }
}

// Define a class representing Angie's adventure
class Adventure {
    var location: String
    
    init(location: String) {
        self.location = location
    }
    
    // Method to start the adventure
    func startAdventure(with angie: Student, and dogs: [Dog]) {
        print("\(angie.name) and her dogs are embarking on an adventure in \(location)! Let's go!\n")
        
        // Print introduction
        print("Welcome to the magical Swift playground adventure!")
        print("Angie, Amor, and Princess are on a journey to learn Swift programming while having fun.\n")
        
        // Start the first challenge
        print("Challenge 1: The Great Entrance")
        print("Angie, Amor, and Princess need to find the entrance to the enchanted Swift castle.")
        print("They must solve a riddle to reveal the entrance.\n")
        
        // Solve the riddle
        print("Riddle: What is the keyword used to define a constant in Swift?")
        print("a) let")
        print("b) var")
        print("c) const")
        print("d) final")
        
        if let answer = readLine() {
            switch answer {
            case "a":
                print("Correct! 'let' is used to define a constant in Swift.\n")
                print("Angie, Amor, and Princess found the entrance and entered the castle!\n")
                // Continue to the next challenge
                nextChallenge(with: angie, and: dogs)
            default:
                print("Incorrect! Try again.")
                startAdventure(with: angie, and: dogs) // Retry the challenge
            }
        }
    }
    
    // Method to continue to the next challenge
    private func nextChallenge(with angie: Student, and dogs: [Dog]) {
        // Challenge 2: The Magical Loop
        print("Challenge 2: The Magical Loop")
        print("Angie, Amor, and Princess encounter a magical loop that can duplicate objects.")
        print("They must use the loop to create copies of themselves to proceed.\n")
        
        // Create copies of Angie, Amor, and Princess
        var copies: [String] = []
        for dog in dogs {
            copies.append(dog.name)
        }
        copies.append(angie.name)
        
        print("Angie, Amor, and Princess created copies of themselves:")
        for copy in copies {
            print("- \(copy)")
        }
        print("\nNow they can proceed to the next challenge!\n")
        
        // Challenge 3: The Swift Puzzle
        print("Challenge 3: The Swift Puzzle")
        print("Angie, Amor, and Princess encounter a puzzle made of Swift code blocks.")
        print("They must rearrange the blocks to form a valid Swift function to unlock the path forward.\n")
        
        // Puzzle blocks
        let blocks = ["func", "(", ")", "{", "}"]
        
        print("Puzzle Blocks:")
        for block in blocks {
            print("- \(block)")
        }
        
        print("\nRearrange the blocks to form a valid Swift function:")
        print("func greet() {")
        print("    print(\"Hello, world!\")")
        print("}")
        
        // Check if the puzzle is solved
        var solved = false
        while !solved {
            print("\nIs the puzzle solved? (yes/no)")
            if let answer = readLine()?.lowercased() {
                if answer == "yes" {
                    print("\nCongratulations! The puzzle is solved.")
                    solved = true
                } else if answer == "no" {
                    print("Keep rearranging the blocks.")
                } else {
                    print("Invalid input. Please enter 'yes' or 'no'.")
                }
            }
        }
        
        // Final challenge completed
        print("\nAngie, Amor, and Princess solved the puzzle and unlocked the path forward!\n")
        print("Congratulations! You've completed the magical Swift playground adventure!")
    }
}

// Define Angie's dogs
let amor = Dog(name: "Amor")
let princess = Dog(name: "Princess")

// Create an instance of Angie
let angie = Student(name: "Angie")

// Create an instance of the adventure
let swiftAdventure = Adventure(location: "the enchanted Swift playground")

// Start the adventure
angie.exploreSwiftPlaygrounds()
swiftAdventure.startAdventure(with: angie, and: [amor, princess])
