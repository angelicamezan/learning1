import Foundation

//Coding following along tutorials to understand these on Feb 20th

let myName = "Angie"
let myAge = 20
let yourName = "Foo"
let yourAge = 19

if myName == "angie"{
    "Your name is \(myName)"
} else{
    "Oops, I guessed it wrong"
}

if myName == "Angie"{
    "Now I guessed it correctly"
}else if myName == "Foo"{
    "Are you foo?"
}else{
    "I give up"
}
    

if myName == "Angie" && myAge == 30 {
    "Name is Angie and age is 30"
}else if myAge == 20{
    "I only guessed the age right"
}else{
    "I give up"
}

if myAge == 20 || myName == "Foo"{
    "Either age is 20, name is Foo or both"
}

// OR is ||
// AND is &&

var isWinner:Bool{

        for moves in Moves.winningMoves{

            if moves.allSatisfy(self.moves.contains){

                return true

            }

        }

        return false

    }
