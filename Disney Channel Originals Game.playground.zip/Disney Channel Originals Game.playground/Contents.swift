import Foundation
//This is a fun, non-app game I made in a playground just to get used to how to use functions, variables, etc. It was fun To make. I made it on 3/9
// Define Disney Channel Original Movies and their corresponding descriptions
let disneyOriginals = [
    "Halloweentown": "A young girl discovers that she comes from a family of witches and must save her hometown from evil forces on Halloween.",
    "High School Musical": "A high school basketball player and a shy new student discover a shared love for singing and try out for their school musical.",
    "The Cheetah Girls": "Four high school friends form a girl group and pursue their dreams of becoming pop stars while facing challenges along the way.",
    "Zenon: Girl of the 21st Century": "A girl living on a space station is sent to Earth as punishment, where she discovers new friends and an evil plot.",
    "Cadet Kelly": "A rebellious teenage girl is sent to military school where she clashes with authority but ultimately learns important life lessons.",
    "Pixel Perfect": "A young musician creates a holographic pop star to improve his band's image, but soon faces the consequences of artificial perfection.",
    "Johnny Tsunami": "A Hawaiian teenage surfer must adapt to life in Vermont and conquer the mountain slopes after his family moves for his father's job."
]

// Function to present multiple-choice options for a DCOM description
func presentDCOMDescription(with options: [String], correctAnswer: String) -> Bool {
    print("Guess the Disney Channel Original Movie from the following description:")
    print("A) \(options[0])")
    print("B) \(options[1])")
    print("C) \(options[2])")
    print("D) \(options[3])")
    
    if let userGuess = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines) {
        switch userGuess.lowercased() {
        case "a":
            return options[0] == correctAnswer
        case "b":
            return options[1] == correctAnswer
        case "c":
            return options[2] == correctAnswer
        case "d":
            return options[3] == correctAnswer
        default:
            return false
        }
    }
    return false
}

// Main game loop
func playDCOMGame() {
    print("Welcome to the Disney Channel Original Movie Guessing Game!")
    print("Guess the DCOM from the provided description. Let's begin!\n")
    
    var score = 0
    var playAgain = true
    
    while playAgain {
        print("Choose difficulty level: ")
        print("1) Easy (Multiple Choice)")
        print("2) Hard (Type Your Guess)")
        
        if let difficultyInput = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines),
           let difficulty = Int(difficultyInput) {
            
            if difficulty == 1 {
                let randomIndex = Int.random(in: 0..<disneyOriginals.count)
                let movie = Array(disneyOriginals.keys)[randomIndex]
                let description = disneyOriginals[movie]!
                let options = Array(disneyOriginals.keys).shuffled().prefix(4)
                let correctAnswer = movie
                
                print(description)
                if presentDCOMDescription(with: options, correctAnswer: correctAnswer) {
                    print("Correct! You guessed \(correctAnswer)!")
                    score += 1
                } else {
                    print("Incorrect. The correct answer is \(correctAnswer).")
                }
            } else if difficulty == 2 {
                let randomIndex = Int.random(in: 0..<disneyOriginals.count)
                let movie = Array(disneyOriginals.keys)[randomIndex]
                let description = disneyOriginals[movie]!
                
                print(description)
                if let userGuess = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines) {
                    if userGuess.lowercased() == movie.lowercased() {
                        print("Correct! You guessed \(movie)!")
                        score += 2
                    } else {
                        print("Incorrect. The correct answer is \(movie).")
                    }
                }
            } else {
                print("Invalid input. Please enter 1 or 2.")
            }
            
            print("Your current score is \(score).")
            print("\nDo you want to play again? (yes/no)")
            if let userInput = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines) {
                if userInput.lowercased() != "yes" {
                    playAgain = false
                }
            } else {
                playAgain = false
            }
        } else {
            print("Invalid input. Please choose a difficulty level.")
        }
    }
    
    print("Thanks for playing! Your final score is \(score).")
}

// Start the game
playDCOMGame()

