import Foundation // includes all basics of how swift works like ints, options, etc

//VARIABLES

let myName = "Angie"//cannot be assigned to again
var yourName = "Joaquin" //can be assigned to again

//myName = yourName will give an error

var names = [myName, yourName]
names.append("Lilly")
names = ["Bla"] // totally changes or mutates names
// bc the array is a var, you can add to it. IF the array was a let, wouldn't be able to append or remove

let foo = "foo"
var foo2 = foo //contains foo
foo2 = "Foo 2"
print(foo,foo2) //would print "foo" "foo2"

let moreNames = ["Foo", "Bar" ]
var copy = moreNames
copy.append("Baz")
print(moreNames) // would print the OG moreNames
print(copy) // prints "Foo", "Bar", "Baz"


 
