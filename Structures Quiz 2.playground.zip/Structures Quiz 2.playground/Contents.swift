import Foundation
// February 27th Tutorial STRUCTURES: way of grouping data together , they are value types
//Variables in structures are called PROPERTIES

struct Person{
    let name: String
    let age: Int
}
let foo = Person(name:"foo", age:20)

//dot notation to access properties of a structure

foo.name
foo.age

struct CommodoreComputer {
    let name: String
    let manufacturer: String
    init(name:String){
        self.name = name
        self.manufacturer = "Commodore"
    }
}

let c64 = CommodoreComputer(name: "C64")
c64.name
c64.manufacturer


//computed properties (aka variables as functions)

struct Person2{
    let firstName: String
    let lastName: String
    var fullName: String{
        "\(firstName) \(lastName)"
    }
}

let fooBar = Person2(firstName: "Foo", lastName: "Bar")
fooBar.firstName
fooBar.lastName
fooBar.fullName


//structures that can be mutable
struct Car {
    var currentSpeed: Int
    mutating func drive(speed:Int){
        "Driving..."
        currentSpeed = speed
    }
}

let immutableCar = Car(currentSpeed: 10)
//immutableCar.drive(speed: 20)//Cannot use mutating member on immutable value: 'immutableCar' is a 'let' constant. Change let to var to make it mutable

var mutableCar = Car(currentSpeed: 10)
let copy = mutableCar
mutableCar.drive(speed: 30)
mutableCar.currentSpeed
copy.currentSpeed

struct LivingThing {
    init() {
        "I'm a living thing"
    }
}
//struct Animal: LivingThing{
//}
//Structures cannot inherit from each other

struct Bike{
    let manufacturer: String
    let currentSpeed: Int
    func copy(currentSpeed:Int)-> Bike{
        Bike(manufacturer: self.manufacturer, currentSpeed:currentSpeed)
    }
}

let bike1 = Bike(manufacturer:"HD",currentSpeed:20)


