import Foundation
//February 23
//OPERATORS

let myAge = 22
let yourAge = 20

if myAge > yourAge{
    "I'm older than you"
} else if myAge < yourAge {
    "I'm younger than you"
}else {
    "Oh hey, we are the same age"
}
let myMotherAge = myAge+30
let doubleMyAge = myAge*2

let message: String if age>= 18 {
    mesagge = "You are an adult"
} else{
    message = "You're no adult"
}
//OTHER WAY TO DO THIS
let message = age >= 18//CONDITION
    ? "You are an adult"// ? Value if condition is met
    : "You're not an ault yet"// value if condition NOT met

