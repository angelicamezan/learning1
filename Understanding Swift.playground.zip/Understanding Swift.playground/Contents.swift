import UIKit
import Foundation
//Code of March 1st, 2024
var greeting = "Hello, playground"
// Variables and Constants
var myName = "Angie"
let myAge = 20

// Basic operations
var x = 10
var y = 5
var sum = x + y
var difference = x - y
var product = x * y
var quotient = x / y

// Strings and String Interpolation
var greeting = "Hello, \(myName)! You are \(myAge) years old."

// Arrays and Loops
var fruits = ["Apple", "Banana", "Orange"]
for fruit in fruits {
    print("I like \(fruit)s!")
}
// Function definition
func greet(name: String) -> String {
    return "Hello, \(name)!"
}

// Function call
var message = greet(name: "Alice")

// Conditional statements
var isRaining = true
if isRaining {
    print("Don't forget your umbrella!")
} else {
    print("Enjoy the sunshine!")
}

// Switch statement
var dayOfWeek = "Monday"
switch dayOfWeek {
case "Monday":
    print("It's Monday!")
case "Friday":
    print("It's Friday!")
default:
    print("It's another day.")
}
// Optional variables
var optionalName: String? = "Bob"
var greetingMessage = "Hello"
if let name = optionalName {
    greetingMessage = "Hello, \(name)"
} else {
    greetingMessage = "Hello, stranger"
}

// Error handling
func divide(_ a: Int, by b: Int) throws -> Int {
    guard b != 0 else {
        throw NSError(domain: "DivisionError", code: 1, userInfo: nil)
    }
    return a / b
}

do {
    let result = try divide(10, by: 2)
    print("Result of division: \(result)")
} catch {
    print("Error occurred: \(error)")
}
