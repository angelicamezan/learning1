import Foundation
//Quiz 2 Prep February 28th
//enumerations: categorization of similar data together by inate
enum Animals{
    case cat
    case dog
    case rabbit
}
let cat = Animals.cat
cat

if cat == Animals.cat {
    "this is cat"
}else if cat == Animals.dog{
    "this is a dog"
}else {
    "this is something else"
}

func describeAnimal(_ animal: Animals){
    switch animal {
        
    case .cat:
        "This is a cat"
        break
    case .dog:
        "This is a dog"
        break
    case .rabbit:
        "This is a rabbit"
        break
    }
}
describeAnimal(Animals.rabbit)

enum Shortcut{
    case fileOrFolder
    case wwwUrl(path:URL)
    case song
}
let wwwApple == Shortcut.wwwUrl(path: URL(String: "https://apple.com")!) {
    
}

